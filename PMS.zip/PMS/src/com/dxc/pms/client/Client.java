package com.dxc.pms.client;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import com.dxc.pms.dbcon.MyConnection;
import com.dxc.pms.model.Product;

public class Client {
	static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) throws ClassNotFoundException, SQLException  {
		
		Connection con = MyConnection.getDBconnection();
		
		
		 
        while (true) {
        	System.out.println("\n%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
            System.out.println("\n|| MAIN MENU || ");
            System.out.println("\n1. Add Product");
            System.out.println("2. Delete Product");
            System.out.println("3. Update Product");
            System.out.println("4. Find Product by Id");
            System.out.println("5. Find All Products ");
            System.out.println("6. E X I T");
            System.out.print("\nPlease enter your choice (1-6) : ");
            int choice = sc.nextInt();
            switch (choice) {
            case 1:
                System.out.println("Adding Products  ");
                addProduct(con);
                break;
            case 2:
                System.out.println("Deleting Products  ");
                deleteProduct(con);
                break;
            case 3:
                System.out.println("Updating Products  ");
                updateProduct(con);
                break;
            case 4:
                System.out.println("\nFinding Products by id");
                displayProductById(con);
                break;
            case 5:
                displayProducts(con);             
                break;
            case 6:
                System.out.println("Thanks for using my program");
                System.exit(0);
            default:
                System.out.println("Incorrect Option . Please select (1-6)");
            }
        }
    }
	private static void updateProduct(Connection con) throws SQLException {
		System.out.println("Please Entert the Detail Of Product");
		System.out.print("\nEnter Product Id : ");int pID = sc.nextInt();
		System.out.print("\nEnter Product Name : ");String pName = sc.next();
		System.out.print("\nEnter Product quantity : ");int qoh = sc.nextInt();
		System.out.print("\nEnter Product Price : ");int price = sc.nextInt();
		
		PreparedStatement stat = con.prepareStatement("update hr.product set productName = ?, quantityOnHand = ?,price = ? where productId = ?");
		
		stat.setString(1, pName);
		stat.setInt(2, qoh);
		stat.setInt(3, price);
		stat.setInt(4, pID);
		
		int rows = stat.executeUpdate();
		
		System.out.println("\n*****  "+ rows + " rows affected *****");
		System.out.println("\n"+pName + "  Successfully Updated ");
		
	}
	private static void deleteProduct(Connection con) throws SQLException {
		System.out.println("Please Entert the Detail Of Product");
		System.out.print("\nEnter Product Id : ");int pID = sc.nextInt();
		PreparedStatement stat = con.prepareStatement("delete from hr.product where productId = ?");
		stat.setInt(1, pID);
		int rows = stat.executeUpdate();
		System.out.println("\n*****  "+ rows + " rows affected *****");
		System.out.println("\n"+pID + "  Successfully Deleted ");
		
	}
	private static void addProduct(Connection con) throws SQLException {
		System.out.println("Please Entert the Detail Of Product");
		System.out.print("\nEnter Product Id : ");int pID = sc.nextInt();
		System.out.print("\nEnter Product Name : ");String pName = sc.next();
		System.out.print("\nEnter Product quantity : ");int qoh = sc.nextInt();
		System.out.print("\nEnter Product Price : ");int price = sc.nextInt();
		
		PreparedStatement stat = con.prepareStatement("insert into hr.product values(?,?,?,?)");
		stat.setInt(1, pID);
		stat.setString(2, pName);
		stat.setInt(3, qoh);
		stat.setInt(4, price);
		
		int rows = stat.executeUpdate();
		
		System.out.println("\n*****  "+ rows + " rows affected *****");
		System.out.println("\n"+pName + "  Successfully Added ");
		
		
	}
	private static void displayProductById(Connection con) throws SQLException {
		System.out.println("Product Displaying By Id");
		System.out.print("Please Enter Product id To Search :");
		int pId = sc.nextInt();
		System.out.println("You Want To Search For : " + pId );
		PreparedStatement stat = con.prepareStatement("select * from hr.product where productId = ? ");
		stat.setInt(1,pId);
		ResultSet res = stat.executeQuery();
		
		if(res.next())
		{
			System.out.print("\n"+ res.getString(1) + " ");
			System.out.print(res.getString(2) + " ");
			System.out.print(res.getString(3) + " ");
			System.out.println(res.getString(4));
	     }
		
		else
		{
			System.out.println("No Products exists For ProductId : "+ pId) ;
		}
	}
	private static void displayProducts(Connection con) throws SQLException {
		System.out.println("Displaying all the  Products : ");
		Statement stat = con.createStatement();
		ResultSet res = stat.executeQuery("select * from hr.product");
		ResultSetMetaData rsmd = res.getMetaData();
		int count = rsmd.getColumnCount();
		while(res.next()) {
			System.out.println("\n");	
			for(int i =1;i<=count;i++)
			{
				System.out.print(rsmd.getColumnName(i)+ " ");
			}
				
			System.out.println("\n");	
			for(int i =1;i<=count;i++)
			{
				System.out.print(res.getString(i)+ " ");
			}
			System.out.println("\n");		
			
			
//		System.out.print("\n"+ res.getString(1) + " ");
//		System.out.print(res.getString(2) + " ");
//		System.out.print(res.getString(3) + " ");
//		System.out.println(res.getString(4));
//		
		}
	}
}
		
		
		
		
		
		
		
		
//		Product product = new Product(100, "computer", 20, 1000000);
//		product.setProductid(20);
//			System.out.println(product);
//		System.out.println(product.getProductName());




