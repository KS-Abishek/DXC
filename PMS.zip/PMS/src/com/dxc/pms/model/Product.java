package com.dxc.pms.model;

public class Product {
	
	private int productId;
	private String productName;
	private int quantityOnHand;
	private int price;
	public Product() {
		super();
	}
	public Product(int productid, String productName, int quantity, int price) {
		super();
		this.productId = productid;
		this.productName = productName;
		this.quantityOnHand = quantity;
		this.price = price;
	}

	public int getProductid() {
		return productId;
	}
	public void setProductid(int productid) {
		this.productId = productid;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getQuantity() {
		return quantityOnHand;
	}
	public void setQuantity(int quantity) {
		this.quantityOnHand = quantity;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	
	
	@Override
	public String toString() {
		return "Product [productid=" + productId + ", productName=" + productName + ", quantity=" + quantityOnHand
				+ ", price=" + price + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + price;
		result = prime * result + ((productName == null) ? 0 : productName.hashCode());
		result = prime * result + productId;
		result = prime * result + quantityOnHand;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Product other = (Product) obj;
		if (price != other.price)
			return false;
		if (productName == null) {
			if (other.productName != null)
				return false;
		} else if (!productName.equals(other.productName))
			return false;
		if (productId != other.productId)
			return false;
		if (quantityOnHand != other.quantityOnHand)
			return false;
		return true;
	}
	
}


/*
 * customerId number, customerName varchar2(20), customerAddress varchar2(20),
 * billAmount number
 */

