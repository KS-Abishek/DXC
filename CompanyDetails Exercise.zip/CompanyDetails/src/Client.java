import finance.*;
import finance.gst.*;
import hr.*;
public class Client {
	
	public void message() {
		System.out.println("hello from Client");
	}


	public static void main(String[] args) {
		Client c = new Client();
		c.message();
		
		//Hr
		Employee e = new Employee();
		e.details();
		
		//Hr
		Manager m = new Manager();
		m.head();
		
		
		//finance
		Salary s = new Salary();
		s.cash();
		//finance
		Pf p = new Pf();
		p.saving();
		//finance
		Hra h = new Hra();
		h.save();
		
		
		//finance.gst
		Cgst cg = new Cgst();
		cg.rateCgst();
	
		
		//finance.gst
		Sgst sg = new Sgst();
		sg.rateSgst();
		
	}

}
