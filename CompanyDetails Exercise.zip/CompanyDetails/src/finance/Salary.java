package finance;

public class Salary {
	
	public void cash() {
		System.out.println("hello from salary");
	}


}
