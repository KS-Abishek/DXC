package finance;

public class Pf {
	
	public void saving() {
		System.out.println("hello from Pf");
	}

}
