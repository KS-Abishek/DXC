package finance.gst;

public class Cgst {
	
	public void rateCgst() {
		System.out.println("hello from Cgst");
	}


}
