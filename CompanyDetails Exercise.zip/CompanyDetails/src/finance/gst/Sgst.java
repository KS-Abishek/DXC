package finance.gst;

public class Sgst {
	
	public void rateSgst() {
		System.out.println("hello from Sgst");
	}

}
