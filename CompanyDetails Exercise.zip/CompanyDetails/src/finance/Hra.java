package finance;

public class Hra {
	
	public void save() {
		System.out.println("hello from Hra");
	}


}
