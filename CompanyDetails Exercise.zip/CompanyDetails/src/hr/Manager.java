package hr;

public class Manager {
	
	public void head() {
		System.out.println("hello from Manager");
	}


}
