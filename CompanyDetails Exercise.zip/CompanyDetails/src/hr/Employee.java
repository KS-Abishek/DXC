package hr;

public class Employee {
	public void details() {
		System.out.println("hello from Employee");
	}

}
